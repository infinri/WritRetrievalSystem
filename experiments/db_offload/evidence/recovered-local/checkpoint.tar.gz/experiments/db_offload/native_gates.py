"""Real-engine projection gates. Unsupported canonical-memory semantics stay explicit."""
import argparse,contextlib,copy,json,os,subprocess,tempfile,time
from pathlib import Path
import numpy as np
from .adapters import Native
from .data import load,permitted,norm,fuse,render,score
from .engine import neo4j_server,Neo4jHTTP

@contextlib.contextmanager
def restart_server(home,root):
 log=(root/'restart-console.log').open('w');p=subprocess.Popen([str(home.resolve()/'bin/neo4j'),'console'],env={**os.environ,'NEO4J_CONF':str((root/'conf').resolve())},stdout=log,stderr=subprocess.STDOUT);db=Neo4jHTTP()
 try:
  for _ in range(300):
   if p.poll() is not None:raise RuntimeError('server restart failed')
   try:db.execute('RETURN 1 AS ready');break
   except Exception:time.sleep(.2)
  else:raise TimeoutError('restart readiness')
  yield db
 finally:
  p.terminate()
  try:p.wait(timeout=20)
  except subprocess.TimeoutExpired:p.kill();p.wait()
  log.close()

def gates(n,units,vectors,edges,task,settings):
 rows=[]
 def check(name,fn):
  start=time.perf_counter()
  try:fn();rows.append({'gate':name,'status':'PASS','ms':(time.perf_counter()-start)*1000})
  except Exception as e:rows.append({'gate':name,'status':'FAIL','error':str(e),'kind':type(e).__name__})
 scope=n.prepare(units,vectors,edges);view=n.views[scope]
 def exact():
  ranked=n.search(scope,'source',vectors[0],5,.3);lex,vec=n.lists(scope,'source',vectors[0],5,.3)
  assert [r['uid'] for r in ranked]==[r['uid'] for r in fuse(lex,vec,5)]
  assert all(r['uid'] in {u['id'] for u in units} for r in ranked)
 check('native fusion, qualified citations and stable ties',exact)
 def generation():
  changed=copy.deepcopy(units);changed[0]['source_revision']='newer-claim';changed[0]['recorded_at']='2026-11-14T00:00:00Z'
  replacement=n.prepare(changed,vectors,edges);assert replacement!=scope
  n.search(replacement,'source',vectors[0]);n.search(scope,'source',vectors[0])
  retired=n.prepare(units[1:],vectors[1:],edges);assert all(r['uid']!=units[0]['id'] for r in n.search(retired,'source',vectors[0]))
 check('read-after-write, revision replacement, withdrawal and previous generation recoverable',generation)
 def foreign():
  foreign=[{**u,'project':'foreign','id':u['id'].replace('writ|','foreign|')} for u in units]
  assert permitted({'units':units+foreign},task)==units
  before=n.search(scope,'source',vectors[0],2,.3)
  n.prepare(foreign,vectors,[])
  assert n.search(scope,'source',vectors[0],2,.3)==before
 check('foreign rows cannot influence permitted fulltext/vector partition',foreign)
 def failure():
  n.execute('MATCH (p:BOPublished {scope:$scope}) SET p.manifest="broken"',{'scope':scope})
  try:n.search(scope,'source',vectors[0]);raise AssertionError('corrupt manifest served')
  except ValueError:pass
  n.execute('MATCH (p:BOPublished {scope:$scope}) SET p.manifest=$m',{'scope':scope,'m':json.dumps(view['manifest'],sort_keys=True)})
  n.search(scope,'source',vectors[0])
 check('cache/manifest corruption fails closed and recovery is explicit',failure)
 def imports():
  for bad in ([units[0],units[0]],[{**units[0],'verification_status':'verified'}],[{**units[0],'approval_status':'approved'}]):
   try:n.prepare(bad,vectors[:len(bad)],[]);raise AssertionError('untrusted import accepted')
   except ValueError:pass
 check('duplicate identities and self-awarded verification/approval rejected',imports)
 def budget():
  ranked=n.search(scope,'source',vectors[0]);c=render(task,ranked,units,scope,settings)
  assert c['bytes']<=settings['budget_bytes'] and c['characters']<=settings['budget_chars']
  try:render(task,ranked,units,scope,{**settings,'budget_bytes':800},conflicts=[(units[0]['id'],units[1]['id'])],required=[units[0]['id']]);raise AssertionError('required bundle truncated')
  except ValueError as e:assert 'BUDGET' in str(e)
 check('complete required bundle or budget error; byte and character ceilings',budget)
 def paths():
  local=units[:4];e=[{'a':local[a]['id'],'b':local[b]['id'],'a_digest':local[a]['content_digest'],'b_digest':local[b]['content_digest'],'kind':kind,'source_uri':local[a]['source_uri']} for a,b,kind in [(0,1,'CONTINUES'),(1,0,'REFERENCES'),(1,2,'IRRELEVANT')]]
  sc=n.prepare(local,vectors[:4],e);out=n.search(sc,'nonsense',vectors[0],1,.3,connected=True);assert len(out)==len({r['uid'] for r in out}) and len(out)<=64
 check('cycles, bounded traversal and irrelevant edge exclusion',paths)
 def brokenpayload():
  n.execute(f'MATCH (n:{view["label"]} {{uid:$id}}) SET n.payload="{{}}"',{'id':units[0]['id']})
  try:n.search(scope,'source',vectors[0],len(units),-.99);raise AssertionError('corrupt citation served')
  except ValueError:pass
  n.execute(f'MATCH (n:{view["label"]} {{uid:$id}}) SET n.payload=$payload',{'id':units[0]['id'],'payload':json.dumps(units[0],sort_keys=True)})
 check('stored exact source/revision/digest validation',brokenpayload)
 def missingindex():
  n.execute('DROP INDEX '+view['vi'])
  try:n.search(scope,'source',vectors[0]);raise AssertionError('missing index served fresh')
  except Exception as e:
   if isinstance(e,AssertionError):raise
 check('index failure is explicit, never reported as fresh empty result',missingindex)
 return rows,scope,view

def main():
 p=argparse.ArgumentParser();p.add_argument('--neo4j-home',type=Path,required=True);p.add_argument('--work',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();a.work.mkdir(parents=True,exist_ok=False)
 c,t,s=load();task=t[0];u=permitted(c,task)[:8];v=norm(np.ones((len(u),384)));result={'version':'native-projection-gates/1','engines':{},'not_established':['live canonical-memory to native projection bridge','trusted shared publication','canonical evidence retraction/replay inside Neo4j','storage-device failure atomicity; only actual transaction rollback covered in original Relate tests','full cold CLI context recovery; index recovery is tested separately']}
 n=Native(a.work/'relate',heavy=True);result['engines']['relate']={'version':n.execute('CALL dbms.components()'),'gates':gates(n,u,v,c['edges'],task,s)[0]};n.close()
 with neo4j_server(a.neo4j_home,a.work/'neo4j',readiness_seconds=60) as (db,_,startup):
  n=Native(db=db,heavy=True,kind='neo4j');rows,_,_=gates(n,u,v,c['edges'],task,s)
  # Separate intact generation for real process-restart recovery.
  sc=n.prepare(u[2:],v[2:],[]);view=n.views[sc];expected=n.search(sc,'source',v[0]);version=n.execute('CALL dbms.components()')
  from neo4j import GraphDatabase,__version__
  with GraphDatabase.driver('bolt://127.0.0.1:17687',auth=None) as driver:
   with driver.session() as session:bolt=list(session.run('RETURN 1 AS ready'))[0]['ready']==1
  result['engines']['neo4j']={'version':version,'transport':'HTTP JSON; separate Bolt readiness probe only','bolt_driver':__version__,'bolt_probe':bolt,'startup_ms':startup,'gates':rows}
 start=time.perf_counter()
 with restart_server(a.neo4j_home,a.work/'neo4j') as db:
  n=Native(db=db,kind='neo4j',heavy=True);n.views[sc]=view;assert n.search(sc,'source',v[0])==expected
  result['engines']['neo4j']['restart_ms']=(time.perf_counter()-start)*1000;rows.append({'gate':'actual server process restart retains indexes and exact result','status':'PASS'})
 a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
 if any(r['status']!='PASS' for x in result['engines'].values() for r in x['gates']):raise SystemExit(1)
if __name__=='__main__':main()
