"""Randomized isolated performance profiles; timeout/failure records are retained."""
import argparse,json,os,random,signal,subprocess,sys,time
from pathlib import Path

def main():
 p=argparse.ArgumentParser();p.add_argument('--model-dir',type=Path,required=True);p.add_argument('--neo4j-home',type=Path,required=True);p.add_argument('--work',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--samples',type=int,default=1000);p.add_argument('--arms',default='A,B,C,D');a=p.parse_args();a.work.mkdir(parents=True,exist_ok=False);a.output.mkdir(parents=True,exist_ok=False)
 profiles=[(growth,readers,arm) for growth in (1,10,100) for readers in (1,4) for arm in a.arms.split(',')];random.Random(20261113).shuffle(profiles)
 (a.output/'order.json').write_text(json.dumps(profiles,indent=2)+'\n')
 for growth,readers,arm in profiles:
  name=f'{arm}-{growth}-{readers}';output=a.output/(name+'.json');log=(a.output/(name+'.log')).open('w');command=[sys.executable,'-m','experiments.db_offload.perf','--arm',arm,'--growth',str(growth),'--readers',str(readers),'--samples',str(a.samples),'--model-dir',str(a.model_dir),'--neo4j-home',str(a.neo4j_home),'--work',str(a.work/name),'--output',str(output)]
  start=time.perf_counter();process=subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  try:code=process.wait(timeout=300)
  except subprocess.TimeoutExpired:
   os.killpg(process.pid,signal.SIGTERM)
   try:process.wait(timeout=10)
   except subprocess.TimeoutExpired:os.killpg(process.pid,signal.SIGKILL);process.wait()
   output.write_text(json.dumps({'arm':arm,'growth':growth,'readers':readers,'status':'TIMEOUT','timeout_seconds':300,'note':'Outer total process limit includes model, import, query and shutdown; no latency percentile reported.'},indent=2)+'\n')
  log.close()
  if not output.exists():output.write_text(json.dumps({'arm':arm,'growth':growth,'readers':readers,'status':'PROCESS_FAILED','exit':process.returncode})+'\n')
  print(name,json.loads(output.read_text())['status'],round(time.perf_counter()-start,2),flush=True)
if __name__=='__main__':main()
