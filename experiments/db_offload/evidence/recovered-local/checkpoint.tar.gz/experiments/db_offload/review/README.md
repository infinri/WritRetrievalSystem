# Pending independent review

All labels and rubric applications are model-authored and unreviewed. No human
review or adjudicated outcome is claimed. Read the exact public source versions
and full section around each 120-character label; the short clause may omit
qualifications. Record alternatives and warranted unknowns in labels.csv, including
missing rationale/verification/outcomes. Do not infer owner approval from a commit.

For blind review, use blind-contexts.jsonl first, keeping blind-key.json separate.
Score answer sufficiency, citations, historical/lifecycle correctness, contradictions
and abstention independently. Review is not causal attribution or execution approval.

agent-packets.json freezes the same-budget A-hybrid and C-flat contexts for the
NOT RUN live-model harness. This is explicitly a fixed-packet experiment, not
live autonomous query rewriting. Actual generative execution needs a separately
authorized local OpenAI-compatible host, exact model ID/revision and tools support.
