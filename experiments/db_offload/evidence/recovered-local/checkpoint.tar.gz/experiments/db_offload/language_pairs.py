"""Counterbalanced thin client-stack probe, separate from complete-system timings."""
import argparse,contextlib,hashlib,json,random,time
from pathlib import Path
import numpy as np
from .adapters import Native
from .data import load,permitted
from .engine import neo4j_server
from .model import Model
from .workers import WorkerDB

def main():
 p=argparse.ArgumentParser();p.add_argument('--backend',choices=['relate','neo4j'],required=True);p.add_argument('--rust',type=Path,required=True);p.add_argument('--ffi',type=Path,required=True);p.add_argument('--model-dir',type=Path,required=True);p.add_argument('--work',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--neo4j-home',type=Path);a=p.parse_args();a.work.mkdir(parents=True,exist_ok=False);c,t,s=load();tasks=[x for x in t if x['partition']=='development'][:4];u=permitted(c,tasks[0]);model=Model(a.model_dir)
 try:v,_=model.encode([x['text'] for x in u]);q,_=model.encode([x['query'] for x in tasks])
 finally:model.close()
 with contextlib.ExitStack() as stack:
  db=None
  if a.backend=='neo4j':db,_,_=stack.enter_context(neo4j_server(a.neo4j_home,a.work/'neo4j',readiness_seconds=60))
  base=Native(a.work/'graph',db=db,kind=a.backend,heavy=True);scope=base.prepare(u,v,[]);view=base.views[scope]
  if a.backend=='relate':base.close()
  clients={}
  for language in ('python','rust'):
   worker=WorkerDB(a.backend,a.work/'graph' if a.backend=='relate' else None,rust=a.rust if language=='rust' else None,ffi=a.ffi);runtime=Native(db=worker,kind=a.backend,heavy=True);runtime.views[scope]=view;stack.callback(runtime.close);clients[language]=runtime
  rows=[];rng=random.Random(s['seed'])
  for i in range(210):
   task=tasks[i%4];order=['python','rust'];rng.shuffle(order);pair={};ids={}
   for language in order:
    start=time.perf_counter();ranked=clients[language].search(scope,task['query'],q[i%4],20,.3,connected=False);pair[language]=(time.perf_counter()-start)*1000;ids[language]=[r['uid'] for r in ranked]
   assert ids['python']==ids['rust'],'client-stack selection mismatch'
   if i>=10:rows.append({'task':task['id'],'order':order,'ms':pair,'selected_ids':ids['python']})
 result={'version':'paired-client-stack/1','backend':a.backend,'n_pairs':len(rows),'order':'seeded random within each pair; both workers open before warmup; 10 pairs warmup','query_only':True,'model_rendering_included':False,'scope':'flat C/D identical queries and data; Python outer contract checks shared','binding_confound':'Python Relate PyO3 / Rust C ABI 2','parity':True,'rows':rows,'p95_ms':{language:float(np.percentile([r['ms'][language] for r in rows],95)) for language in clients},'mean_paired_rust_minus_python_ms':float(np.mean([r['ms']['rust']-r['ms']['python'] for r in rows])),'binary_sha256':hashlib.sha256(a.rust.read_bytes()).hexdigest()}
 a.output.write_text(json.dumps(result,indent=2)+'\n');print(result['p95_ms'])
if __name__=='__main__':main()
