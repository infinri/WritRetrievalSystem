# Proposed decision: retain the working local baseline

**Status: experimental, pending owner review; no replacement is adopted.**

The measurements do not justify replacing Writ retrieval with database-heavy
queries or starting a wholesale Rust port. Keep Relate as the local persistent
memory/graph engine, retain the supported application contracts and existing
retrieval paths, and retain the experimental native adapters for reproducible
comparisons. No production module or dependency is removed. Neo4j remains an
optional loopback server comparison, not a substitute for the Relate entry.

## What the evidence supports

The matched held-out comparison uses the same permitted passages, embeddings,
query preparation and complete output budgets. A-hybrid delivers the required
clauses for 14/20 positive tasks; B-flat/C-flat 13/20; D-flat 12/20. Connected
variants reach 8/20. These are provisional mechanical clause judgments, not
human-reviewed quality or agent success. A-lexical has higher MRR than hybrid
while delivering fewer complete answers, so a single universal quality winner
is not established. Native replacements fail the registered noninferiority
criterion against A-hybrid on this sample. All hybrid arms return an empty
context on only 4/12 warranted-unknown controls.

Development results were more favorable to native search (D-flat 18/20 versus
A-hybrid/B/C 17/20); that advantage did not survive held-out evaluation. Do not
substitute development results, the discarded historical exploratory 7/10, or
Phase 3's weaker connected baseline for the strongest flat comparator.

Application ownership of visibility, immutable bindings, publication, confidence,
replay, abstention/conflicts, exact citations and total context budgets remains
necessary. Native Cypher fusion and bounded expansion work, but are our query
policies rather than additional database guarantees. Global native top-k followed
by project filtering demonstrably loses permitted hits. Permitted-only indexes
avoid that failure at an explicitly measured materialization/duplication cost.

The promising flat responsibility split has also been exercised through thin
Rust clients. The original connected client probes and later flat probes are
separate microbenchmarks, excluding inference and external assembly. Relate's
Python PyO3 versus Rust C ABI is a binding confound; the small Neo4j client
variation cannot establish a language advantage. Complete-system evidence is
required before any language rewrite can be justified as a retrieval improvement.

## Adoption gates that remain open

Native candidate partitions are not yet a supported live projection of all
canonical Decisions/Memories/Evidence. The experiment does not implement trusted
shared publication, canonical feedback/replay inside Neo4j, an end-to-end
conflict detector/bundle constructor, storage-device fault recovery, remote
transport, or full cold CLI context recovery for native profiles. Unit tests of
the retained production path are not evidence that these native integrations
exist. Required conflict closures can be rendered atomically when supplied, but
the quality harness does not automatically discover every conflict. These
unsupported gates prevent adoption regardless of a fast individual run.

Observed resource limits, timeouts and startup failures are retained. Shared-host
p95 differences are descriptive; they do not establish an equal-resource server
winner. Raw ANN recall curves are separate from semantic relevance and from the
strict tie-safe native path, which requests the complete permitted partition.
No live generative-agent experiment ran: there is no configured authorized model
host/model identity. A reproducible paired tool-calling harness and unreviewed
blind review materials are supplied; scripted retrieval is never substituted
for actual agent output.

## Responsibility split and removable code

| Area | Keep now | Possible replacement after all gates pass | Removed now |
|---|---|---|---:|
| Persistent capture/history | `memory` / `reliable.store`, Relate graph | Native query projection over canonical receipts, with atomic rebuild/publish | 0 |
| Embeddings | `retrieval/embeddings.py`, pinned ONNX/tokenizer | None tested; both engines consume the same app-generated vectors | 0 |
| Keyword search | `retrieval/keyword.py`, Tantivy | Relate fulltext in an eligible local profile, if analyzer quality and partition/update costs become acceptable | 0 |
| Vector candidates | HNSW sidecars / exact oracle | Relate exact vector index locally, Neo4j HNSW in a separately qualified server profile | 0 |
| Fusion/order | `retrieval/ranking.py` and legacy weights | A fixed RRF query for a new profile only; weighted doctrine behavior is not interchangeable | 0 |
| Traversal | `retrieval/traversal.py`, record visibility validation | Native bounded traversal, retaining type/binding/visibility checks | 0 |
| Reliability/authority | `reliable/contracts.py`, `session.py`, `review.py`, `budget.py`, owner APIs, offline boundary | No removal established; database search does not grant approval or execution permission | 0 |

`tantivy` and `hnswlib` are potential profile-specific removals, not demonstrated
whole-project removals. `numpy`, `onnxruntime`, `tokenizers`, `pydantic` and Relate
remain needed by supported behavior. Neo4j/psutil and the Rust C ABI are optional
experiment dependencies; moving work into them adds operational/binding costs.
Lines of code and test counts are not used as superiority measures.

## Next decision and rollback

Before reconsidering adoption, independently review the labels/unknowns, freeze
a new held-out set before further tuning, implement a canonical-memory projection
bridge with retraction/replay and required conflict construction, then rerun the
registered gates and complete end-to-end profiles on a controlled machine. Test
remote server workloads explicitly; loopback results cannot answer them. The
registered 3 percentage-point quality margin, 1.20x p95 improvement and 1.10x RSS
limit remain unmet adoption requirements, not targets to reinterpret after results.

Rollback is immediate: use the unchanged production CLI/offline agent and existing
indexes. The experimental namespace and data directories are not consulted by
that path. No baseline code was removed, no architecture replacement is merged,
and this assignment deploys no website or public superiority claim.
