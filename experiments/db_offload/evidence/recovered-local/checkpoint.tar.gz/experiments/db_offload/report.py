"""Mechanical summaries, paired-family uncertainty and every regression."""
import collections,gzip,json,statistics
from pathlib import Path
import numpy as np
from .data import load
from .review import read_rows
from .large_json import read as read_json
ROOT=Path(__file__).parent

def summarize(rows):
 _,tasks,_=load();bytask={t['id']:t for t in tasks};groups={}
 for arm in sorted({r['arm'] for r in rows}):
  r=[x for x in rows if x['arm']==arm];v=[x for x in r if 'metrics' in x];p=[x for x in v if x['metrics']['gold_clauses']];n=[x for x in v if x.get('expected_unknown')];times=[z for x in v for z in x.get('e2e_ms',x.get('composed_e2e_ms',[]))]
  groups[arm]={'n':len(r),'positive_n':20,'unknown_n':12,'errors':len(r)-len(v),'complete_answers':sum(x['metrics']['complete_answer'] for x in p),'delivered_clauses':sum(x['metrics']['delivered_clauses'] for x in p),'clause_denominator':24,'mrr':statistics.mean(x['metrics']['mrr'] for x in p),'mean_precision_incomplete_labels':statistics.mean(x['metrics']['precision'] for x in p),'ndcg_single_clause_only':statistics.mean(x['metrics']['ndcg'] for x in p if x['metrics']['ndcg'] is not None),'ndcg_n':sum(x['metrics']['ndcg'] is not None for x in p),'correct_empty_context_abstentions':sum(x['metrics']['correct_abstention'] for x in n),'unnecessary_empty_context':sum(x['metrics']['unnecessary_abstention'] for x in p),'citation_scope_failures':sum(not(x['metrics']['citation_correct'] and x['metrics']['scope_correct']) for x in v),'context_bytes':{'min':min(x['bytes'] for x in v),'max':max(x['bytes'] for x in v),'mean':statistics.mean(x['bytes'] for x in v)},'latency_n':len(times),'e2e_p50_ms':float(np.percentile(times,50)) if times else None,'e2e_p95_ms':float(np.percentile(times,95)) if times else None,'p99':None,'categories':{}}
  targets=set();delivered=set()
  for row in v:
   task=bytask[row['task_id']];cards=json.loads(row['payload'])['items']
   for g in task['gold']:
    key=(g['source_uri'],g['source_revision'],g['source_digest']);targets.add(key)
    if any((card['source_uri'],card['source_revision'],card['source_digest'])==key and g['answer_text'] in card['text'] for card in cards):delivered.add(key)
  groups[arm]['unique_exact_source_versions_with_clause']={'delivered':len(delivered),'targets':len(targets),'note':'Deduplicated across queries; cannot replace per-query answer sufficiency.'}
  for category in sorted({x['category'] for x in v if 'category' in x}):
   z=[x for x in v if x.get('category')==category];groups[arm]['categories'][category]={'n':len(z),'complete':sum(x['metrics']['complete_answer'] for x in z),'abstentions':sum(x['metrics']['abstained'] for x in z)}
 return groups

def paired(rows):
 lookup={(r['arm'],r['task_id']):r for r in rows};baseline='A-hybrid';results={}
 for arm in sorted({r['arm'] for r in rows}):
  deltas=collections.defaultdict(list);changes=[]
  for (a,task),b in lookup.items():
   if a!=baseline or not b.get('metrics',{}).get('gold_clauses'):continue
   r=lookup.get((arm,task));bm=b['metrics'];rm=r.get('metrics',{}) if r else {};d=[int(rm.get('complete_answer',False))-int(bm['complete_answer']),rm.get('mrr',0)-bm['mrr']];deltas[b['family']].append(d)
   if d!=[0,0]:changes.append({'task_id':task,'complete_delta':d[0],'mrr_delta':d[1]})
  values=np.array([np.mean(x,axis=0) for _,x in sorted(deltas.items())]);rng=np.random.default_rng(20261113);samples=values[rng.integers(0,len(values),(2000,len(values)))].mean(axis=1);lower=np.percentile(samples,5,axis=0)
  results[arm]={'reference':baseline,'positive_families':len(values),'draws':2000,'mean_delta':values.mean(axis=0).tolist(),'one_sided_95_lower':lower.tolist(),'provisional_noninferior':bool(np.all(lower>-.03)),'field_order':['complete_answer','mrr'],'changes':changes,'status':'UNREVIEWED labels; unsupported correctness gates still block adoption'}
 return results

def main():
 c,t,s=load();result={'version':'bakeoff-summary/1','label_status':'MODEL AUTHORED, NOT HUMAN REVIEWED','partitions':{},'performance':{},'decision':'NO ARCHITECTURE REPLACEMENT: correctness integrations incomplete, no established quality/latency/resource adoption win'}
 for track in ('matched','best'):
  rows=read_rows(ROOT/('evidence/heldout-'+track));result['partitions'][track]={'summary':summarize(rows),'paired':paired(rows)}
 rr=ROOT/'evidence/reranker-heldout'
 if rr.exists() and ((rr/'queries.jsonl').exists() or (rr/'queries.jsonl.gz').exists()):
  rows=read_rows(rr);result['reranker']={'summary':summarize(rows),'additional_p50_ms':float(np.median([r['rerank_additional_ms'] for r in rows])),'additional_p95_ms':float(np.percentile([r['rerank_additional_ms'] for r in rows],95)),'incremental_model_peak_rss_kib':max(r['reranker_peak_rss_kib'] for r in rows),'timing':'composed, not directly measured E2E','paired':paired(rows)}
 if 'reranker' in result:
  result['reranker']['within_arm_changes']={}
  for arm in sorted({r['arm'] for r in rows}):
   changes=[]
   for r in rows:
    if r['arm']!=arm or not r['metrics']['gold_clauses']:continue
    changes.append({'task_id':r['task_id'],'complete_delta':int(r['metrics']['complete_answer'])-int(r['before']['complete_answer']),'mrr_delta':r['metrics']['mrr']-r['before']['mrr']})
   result['reranker']['within_arm_changes'][arm]=changes
 for path in sorted((ROOT/'evidence/performance-suite').glob('*.json*')):
  if path.name in {'order.json','large-json-compression.json'}:continue
  r=read_json(path) if not path.name.endswith('.gz') else read_json(Path(str(path)[:-3]));result['performance'][path.name.split('.')[0]]={k:v for k,v in r.items() if k not in {'rows','partial_rows','resource_samples'}}
 curves=read_json(ROOT/'evidence/vector-curves.json');result['vector_curves']={}
 for backend in sorted({r['backend'] for r in curves['rows']}):
  for k in (5,10,20,50):
   rows=[r for r in curves['rows'] if r['backend']==backend and r['k']==k];result['vector_curves'][backend+':'+str(k)]={'queries':len(rows),'mean_strict_recall':statistics.mean(r['strict_recall'] for r in rows),'mean_tie_aware_recall':statistics.mean(r['tie_aware_recall'] for r in rows),'latency_n':sum(len(r['latency_ms']) for r in rows),'raw_query_p95_ms':float(np.percentile([v for r in rows for v in r['latency_ms']],95))}
 (ROOT/'evidence/summary.json').write_text(json.dumps(result,indent=2)+'\n')
 lines=['# Held-out comparison tables','', 'All labels are provisional. Twenty positive tasks (ten families), twelve unknown controls (six families), 24 clause targets per arm. Empty-context abstention is a retrieval metric, not a live-agent judgment. p95 uses 96 repeated timings, not 96 independent tasks; no p99 is reported here.','']
 for track,record in result['partitions'].items():
  lines+=['## '+track,'','| Arm | Complete labelled targets /20 | Clauses /24 | MRR | Empty abstentions /12 | E2E p95 ms | Citation/scope errors |','|---|---:|---:|---:|---:|---:|---:|']
  for arm,r in record['summary'].items():lines.append(f"| {arm} | {r['complete_answers']} | {r['delivered_clauses']} | {r['mrr']:.3f} | {r['correct_empty_context_abstentions']} | {r['e2e_p95_ms']:.1f} | {r['citation_scope_failures']} |")
  lines+=['','Family-bootstrap comparisons against A-hybrid (one-sided 95% lower bounds):','','| Arm | Complete lower | MRR lower | Provisional noninferiority |','|---|---:|---:|---|']
  for arm,r in record['paired'].items():lines.append(f"| {arm} | {r['one_sided_95_lower'][0]:.3f} | {r['one_sided_95_lower'][1]:.3f} | {r['provisional_noninferior']} |")
  lines+=['']
 (ROOT/'TABLES.md').write_text('\n'.join(lines)+'\n')
 print(result['decision'])
if __name__=='__main__':main()
