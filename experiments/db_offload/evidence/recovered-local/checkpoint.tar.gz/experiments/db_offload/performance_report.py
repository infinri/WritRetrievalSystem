"""Report all registered profiles, with block-resampled descriptive uncertainty."""
import json
from pathlib import Path
import numpy as np
from .large_json import read
ROOT=Path(__file__).parent

def main():
 folder=ROOT/'evidence/performance-suite';order=read(folder/'order.json');records={};lines=['# Registered growth/concurrency results','', 'All 24 profiles are reported in registered randomized order. 1x = 188 current permitted units; 10x/100x are synthetic load only. Full model/DB/client observed RSS is counted. Complete profiles have 1,000 warm samples after ten warmups; failed profiles receive no adoption percentiles. OS caches and shared-host contention are uncontrolled. See MEASUREMENT-NOTES.md for CPU, disk, readiness, resource-limit and refresh gaps.','', '| Arm | Growth | Readers | Status | Samples | E2E p50/p95/p99 ms | Peak RSS MiB | Import ms | Work disk MiB | CPU s |','|---|---:|---:|---|---:|---|---:|---:|---:|---:|']
 for growth,readers,arm in order:
  key=f'{arm}-{growth}-{readers}';path=folder/(key+'.json')
  if not path.exists() and not Path(str(path)+'.gz').exists():raise ValueError('Profile not finished: '+key)
  row=read(path);info={k:v for k,v in row.items() if k not in {'rows','partial_rows','resource_samples'}}
  if row['status']=='COMPLETE':
   values=np.array([r['e2e_ms'] for r in row['rows']]);block=50;blocks=values[:len(values)//block*block].reshape(-1,block);rng=np.random.default_rng(20261113);samples=blocks[rng.integers(0,len(blocks),(2000,len(blocks)))].reshape(2000,-1);p95=np.percentile(samples,95,axis=1);info['p95_block_bootstrap_95_interval_ms']=np.percentile(p95,[2.5,97.5]).tolist();info['uncertainty_note']='50-request blocks, 2000 resamples; descriptive uncertainty within this one shared-host run, not independent machine replications.'
  records[key]=info;lat=row.get('latency',{}).get('e2e_ms');timing='/'.join(f'{lat[p]:.1f}' for p in ('p50','p95','p99')) if lat else '-';rss=f"{row['combined_peak_rss_bytes']/1048576:.1f}" if 'combined_peak_rss_bytes' in row else '?';cpu=f"{row['cpu_seconds_waited_process_tree']:.1f}" if 'cpu_seconds_waited_process_tree' in row else 'incomplete'
  lines.append(f"| {arm} | {growth} | {readers} | {row['status']} | {row.get('n','?')} | {timing} | {rss} | {row.get('import_index_ms',0):.1f} | {row.get('disk_bytes',0)/1048576:.1f} | {cpu} |")
 environment=read(ROOT/'evidence/environment.json');lines+=['',f"Shared embedding artifacts: {environment['model_disk_bytes']/1048576:.1f} MiB; Neo4j distribution: {environment['neo4j_distribution_disk_bytes']/1048576:.1f} MiB; installed experiment venv upper bound: {environment['installed_experiment_venv_disk_bytes']/1048576:.1f} MiB. Add these to working storage where applicable. Java/system interpreter deployment footprint is not fully measured; working disk alone is not a total-footprint claim.",'','Native restart times in profiles are engine readiness (`RETURN 1`), excluding model reload and canonical projection repair. Actual Neo4j result recovery is separately measured in native-gates.json. Retraction-to-visible production/native integration latency remains NOT RUN; immutable replacement correctness is established, not a live ingestion SLA.','', 'Block-resampled p95 intervals and all failures are in evidence/performance-summary.json. Empirical p99 has only about ten tail observations/profile; no cross-host p99 claim is made.']
 (ROOT/'PERFORMANCE.md').write_text('\n'.join(lines)+'\n');(ROOT/'evidence/performance-summary.json').write_text(json.dumps({'profiles':records,'complete':sum(r['status']=='COMPLETE' for r in records.values()),'registered':24,'replications_per_profile':1,'cpu_note':'Earlier profiles have incomplete alive-process CPU samples; not comparable total CPU claims.','remote':'NOT RUN','retraction_to_native_visible':'NOT RUN'},indent=2)+'\n')
 print('registered profiles complete:',len(records))
if __name__=='__main__':main()
