# Execution amendments and measurement limits

These do not change frozen data, retrieval policies, thresholds or held-out choices.

* Model worker: explicit ONNX two intra-op / one inter-op thread, common to all
  ownership arms. The first default-thread bring-up is retained but not used as
  final E2E timing evidence. Cold startup and corpus embedding are separate.
* Quality timing includes permitted-set resolution, generation preparation/check,
  inference, candidate queries, fusion/expansion, payload validation and complete
  JSON rendering. Three repetitions per task are deterministic checks, not three
  independent relevance observations. Warm p95 across 96 timings is descriptive;
  no quality-run p99 is reported.
* Performance profiles use an already prepared immutable permitted generation,
  uncached query inference and complete payload assembly. They do not implement
  or include a canonical live-memory refresh bridge. Four readers share one
  serialized model worker and use separate DB connections. Model queue time is
  included. Model startup/import/indexing and graph-process readiness are measured
  outside warm query latency. Query-only timing excludes model/rendering.
* Registered query-phase limit: 180 seconds, combined observed RSS budget 2 GiB,
  target 1,000 successful samples after ten warmups. An outer 300-second process
  limit covers setup/import/shutdown as well; TIMEOUT is not a completed profile.
  Failed profiles do not receive adoption percentiles. Later failures retain raw
  completed samples. The first C-10-1 failure lacks those partial sample timings;
  its count/resources remain, and the missing timings are not reconstructed.
* Every performance profile is a fresh process; the OS cache is uncontrolled.
  The shared host also ran other development/validation jobs during parts of
  the suite. This is not a dedicated-host or equal CPU quota experiment. Do not
  use these descriptive numbers to assert a production speed winner.
* Process-tree RSS is sampled every 20 ms, counting app, model, native reader
  workers and Neo4j descendants. Peaks between samples can be missed. Neo4j's
  512 MiB heap and 128 MiB page cache are not its total RSS. CPU samples originally
  summed only currently alive descendants; late profiles also record SELF plus
  waited CHILDREN getrusage totals. CPU accounting gaps are explicit per record.
* `disk_bytes` is per-profile database/log/index working storage. Add the shared
  model and runtime/distribution footprints from environment.json; do not compare
  this field alone as total system disk. Synthetic growth reuses encoded vectors
  with deterministic tiny jitter and does not measure encoding 100x real documents.
* The 20-second default Neo4j readiness deadline failed under concurrent load.
  Those failures remain in the performance suite. The independent correctness
  retry allowed 60 seconds and passed; it is not substituted as a faster run.
  Native-query capability was established against actual engines, not mocks.
* Initial language probes ran Python then Rust and can contain cache/order bias.
  They are retained. `language-paired-*` uses both live workers, ten warmup pairs,
  200 measured pairs and seeded randomized order within pairs. Both retain Python
  outer contracts. These are thin client-stack query tests, not full Rust context
  pipelines; PyO3 versus C ABI is an additional Relate confound.
* Learned reranking uses 20 candidates, max 384 pair tokens, batch eight, two/one
  ORT threads, raw relevance-logit/ID ordering, no tuned threshold. No development
  or held-out threshold search was performed. It is separate from ownership
  selection and available equally to all four flat hybrid arms. Added latency and
  model RSS are measured independently; reported composed E2E adds this cost to
  earlier E2E (and double-counts baseline rendering), rather than pretending to
  be a directly measured full-system timing. Reusing the added timing three times
  does not create three independent reranker latency samples: there are 128 actual
  rerank calls, including empty candidate controls.
* Raw ANN curves use precomputed vectors, 32 development queries × three timings
  per k/backend. Exact float32 oracle recall is distinct from semantic relevance;
  tied identities can differ without a similarity-quality loss. They are not
  permission-filtering or complete payload latencies. The strict native path
  overrequests all permitted vectors for deterministic final ties, unlike raw ANN.

No remote server, energy/power, isolated multi-writer throughput, actual generative
agent outcome or independently reviewed label claim is inferred from these runs.

Actual `SHOW INDEXES` introspection is saved in `evidence/index-metadata.json`.
Relate reports compatibility HNSW/quantization configuration fields even though
the pinned `vector_index_candidates` source enumerates/scans index population;
configuration names alone are not evidence of ANN execution. The exact source
hash and oracle result are recorded in `index-implementation.json`. Both engines
report `standard-no-stop-words` fulltext metadata, but the measured analyzer
probe shows this does not establish identical scoring/tokenization. Relate's
analyzer-list procedure is unsupported in this build. No conclusion is generalized
to untested newer Neo4j/Relate versions or exhaustive backend configurations.

The RSS budget is cooperative: checked after setup/warmup and during the query
loop, not an OS/cgroup hard limit during index construction. CPU/parent BLAS and
native-engine worker pools are not uniformly core-pinned; environment metadata
records unset thread variables. This further limits equivalent-resource claims.

The public labels are 120-character answer-bearing **proxies**, often spanning a
sentence boundary. The `complete_answer` field means all frozen target proxies
are delivered with exact versions; it is not an independently adjudicated full
answer. Reading the wider qualification is part of pending human review. The
64 formulations represent 32 topic families and only five unique source versions
in the held-out positive labels, limiting external validity. Deduplicated source
coverage and per-query target delivery are both published; neither replaces the
other. The original weighted doctrine benchmark is a separate historical control
(253 prompts × four arms); mandatory-rule delivery remains distinct from ranked
retrieval, including its 21 intentionally excluded coding targets.

The Rust Neo4j client uses HTTP/1.0 with connection-close; Python urllib uses its
HTTP client stack. They send equivalent Cypher/JSON parameters but are not an
identical implementation of the transport. Language microbenchmarks therefore
measure the full thin client stack and cannot isolate language instruction cost.
