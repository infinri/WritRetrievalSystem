"""Fetch only pinned optional experiment engines; no root or credentials required."""
import argparse,hashlib,json,tarfile,urllib.request
from pathlib import Path

def main():
 p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);a=p.parse_args();a.output.mkdir(parents=True,exist_ok=True);metadata=json.loads((Path(__file__).parent/'evidence/environment.json').read_text());urls={'neo4j-community-5.26.0-unix.tar.gz':'https://dist.neo4j.org/neo4j-community-5.26.0-unix.tar.gz','relate-ffi-1.0.1.tar.gz':'https://github.com/relatedb/relate/releases/download/v1.0.1/relate-ffi-x86_64-unknown-linux-gnu.tar.gz'}
 for name,url in urls.items():
  target=a.output/name
  if not target.exists():
   with urllib.request.urlopen(url,timeout=120) as response:target.write_bytes(response.read())
  if hashlib.sha256(target.read_bytes()).hexdigest()!=metadata['archives'][name]['sha256']:raise ValueError('archive digest mismatch '+name)
  with tarfile.open(target) as archive:archive.extractall(a.output,filter='data')
  print(name,'verified and extracted')
 print('Java 21 and Rust 1.85.1 must be installed explicitly in user space; no host packages changed.')
if __name__=='__main__':main()
