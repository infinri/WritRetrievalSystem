"""Isolated process profiles; empirical p99 only after 1000 successful samples."""
import argparse,concurrent.futures,contextlib,copy,hashlib,json,os,resource,statistics,threading,time
from pathlib import Path
import numpy as np
import psutil
from .data import load,permitted,render,norm,digest
from .adapters import Flat,Native
from .model import Model
from .engine import neo4j_server
from .workers import WorkerDB

class Monitor:
 def __init__(self):self.stop=threading.Event();self.peak=0;self.samples=[];self.thread=threading.Thread(target=self.run,daemon=True);self.thread.start()
 def run(self):
  while not self.stop.wait(.02):
   processes=[psutil.Process(),*psutil.Process().children(recursive=True)];rss=0;cpu=0
   for p in processes:
    try:rss+=p.memory_info().rss;t=p.cpu_times();cpu+=t.user+t.system
    except psutil.Error:pass
   self.peak=max(self.peak,rss);self.samples.append({'seconds':time.monotonic(),'rss_bytes':rss,'cumulative_alive_cpu_seconds':cpu})
 def close(self):self.stop.set();self.thread.join()

def main():
 p=argparse.ArgumentParser();p.add_argument('--arm',choices=['A','B','C','D'],required=True);p.add_argument('--growth',type=int,choices=[1,10,100],required=True);p.add_argument('--readers',type=int,choices=[1,4],default=1);p.add_argument('--samples',type=int,default=1000);p.add_argument('--model-dir',type=Path,required=True);p.add_argument('--neo4j-home',type=Path);p.add_argument('--work',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();a.work.mkdir(parents=True,exist_ok=False);a.output.parent.mkdir(parents=True,exist_ok=True)
 corpus,tasks,settings=load();tasks=[t for t in tasks if t['partition']=='development'];task=next(t for t in tasks if t['partition']=='development' and t['category']=='exact');base=permitted(corpus,task);units=[];edges=[];monitor=Monitor();start_total=time.perf_counter();result={'code_sha256':{name:hashlib.sha256((Path(__file__).parent/name).read_bytes()).hexdigest() for name in ('perf.py','adapters.py','model.py','embed.py','data.py','workers.py','engine.py')},'arm':a.arm,'growth':a.growth,'readers':a.readers,'target_samples':a.samples,'synthetic_scaling':a.growth!=1,'status':'RUNNING'}
 try:
  with contextlib.ExitStack() as stack:
   model=Model(a.model_dir);stack.callback(model.close);mutex=threading.Lock();start=time.perf_counter();base_vectors,_=model.encode([u['text'] for u in base]);result['model_startup_ms']=model.startup_ms;result['corpus_embedding_ms']=(time.perf_counter()-start)*1000
   ids={u['id'] for u in base};base_edges=[e for e in corpus['edges'] if e['a'] in ids and e['b'] in ids]
   rng=np.random.default_rng(20261113)
   matrices=[]
   for copy_index in range(a.growth):
    suffix='' if copy_index==0 else ':synthetic-'+str(copy_index)
    units.extend({**u,'id':u['id']+suffix} for u in base)
    edges.extend({**e,'a':e['a']+suffix,'b':e['b']+suffix} for e in base_edges)
    matrices.append(base_vectors if copy_index==0 else norm(base_vectors+rng.normal(0,1e-5,base_vectors.shape)))
   matrix=np.concatenate(matrices);result['units']=len(units);result['embedding_note']='Real corpus encoded once; synthetic copies use registered seed, +/-1e-5 jitter to measure load, not semantic quality.'
   db=None
   if a.arm=='D':db,server,startup=stack.enter_context(neo4j_server(a.neo4j_home,a.work/'neo4j'));result['server_startup_ms']=startup
   root=Flat() if a.arm=='A' else Native(a.work/'graph',db=db,kind='neo4j' if a.arm=='D' else 'relate',heavy=a.arm in {'C','D'})
   start=time.perf_counter();scope=root.prepare(units,matrix,edges);result['import_index_ms']=(time.perf_counter()-start)*1000
   # Keep the no-network model shared, serialized; each database reader has its own connection.
   local=threading.local();workers=[]
   if a.readers==4 and a.arm in {'B','C'}:root.close()
   def request(i):
    if not hasattr(local,'adapter'):
     if a.readers==1 or a.arm=='A':local.adapter=root
     else:
      worker=WorkerDB('neo4j' if a.arm=='D' else 'relate',a.work/'graph' if a.arm in {'B','C'} else None)
      local.adapter=Native(db=worker,kind='neo4j' if a.arm=='D' else 'relate',heavy=a.arm in {'C','D'});local.adapter.views=root.views;workers.append(local.adapter);stack.callback(local.adapter.close)
    query=tasks[(i%4)*2]['query'];item={**task,'query':query};start=time.perf_counter()
    with mutex:vector,inference=model.encode([query])
    query_start=time.perf_counter();ranked=local.adapter.search(scope,query,vector[0],20,.3);query_ms=(time.perf_counter()-query_start)*1000
    output=render(item,ranked,units,scope,settings);return {'e2e_ms':(time.perf_counter()-start)*1000,'query_only_ms':query_ms,'inference_ms':inference,'bytes':output['bytes']}
   for i in range(10):request(i)
   if monitor.peak>settings['rss_budget_mib']*1024**2:raise MemoryError('registered combined RSS budget after import exceeded')
   rows=[];begin=time.perf_counter()
   pool=concurrent.futures.ThreadPoolExecutor(max_workers=a.readers) if a.readers>1 else None
   try:
    values=pool.map(request,range(a.samples)) if pool else map(request,range(a.samples))
    for value in values:
     rows.append(value)
     if time.perf_counter()-begin>settings['timeout_seconds']:raise TimeoutError('registered profile query timeout')
     if monitor.peak>settings['rss_budget_mib']*1024**2:raise MemoryError('registered combined RSS budget exceeded')
   finally:
    if pool:pool.shutdown(wait=True,cancel_futures=True)
   wall=time.perf_counter()-begin
   for worker in workers:worker.close()
   result.update(status='COMPLETE',n=len(rows),throughput_per_second=len(rows)/wall,rows=rows,latency={kind:{'p50':float(np.percentile([r[kind] for r in rows],50)),'p95':float(np.percentile([r[kind] for r in rows],95)),'p99':float(np.percentile([r[kind] for r in rows],99)) if len(rows)>=1000 else None} for kind in ('e2e_ms','query_only_ms')})
   start=time.perf_counter()
   if a.arm in {'B','C'}:
    if a.readers==1:root.close()
    worker=WorkerDB('relate',a.work/'graph');worker.execute('RETURN 1 AS ready');worker.close();result['restart_recovery_ms']=(time.perf_counter()-start)*1000
   else:result['restart_recovery_ms']=None
 except Exception as e:result.update(status='FAILED',error={'kind':type(e).__name__,'message':str(e)},n=len(locals().get('rows',[])),partial_rows=locals().get('rows',[]),partial_timings_note='Raw completed samples retained, but failed profiles have no adoption percentiles.')
 finally:
  monitor.close();self_cpu=resource.getrusage(resource.RUSAGE_SELF);child_cpu=resource.getrusage(resource.RUSAGE_CHILDREN);result['cpu_seconds_waited_process_tree']=self_cpu.ru_utime+self_cpu.ru_stime+child_cpu.ru_utime+child_cpu.ru_stime;result['cpu_accounting_note']='getrusage SELF + waited CHILDREN after explicit child shutdown; short-lived/unwaited orphan descendants not guaranteed. Earlier profiles have alive-process samples only.';result.update(total_wall_seconds=time.perf_counter()-start_total,combined_peak_rss_bytes=monitor.peak,resource_samples=monitor.samples,disk_bytes=sum(p.stat().st_size for p in a.work.rglob('*') if p.is_file()),cpu_note='Samples sum CPU time of currently alive client/model/server descendants. Startup/terminated-child CPU may be incomplete; not energy measurements. Shared host, no cache flush.')
  a.output.write_text(json.dumps(result,indent=2)+'\n')
 print({k:v for k,v in result.items() if k not in {'rows','resource_samples','latency'}})
if __name__=='__main__':main()
