"""Transparent reading and deterministic archival of completed raw JSON evidence."""
import argparse,gzip,hashlib,json
from pathlib import Path

def read(path):
 path=Path(path)
 if path.suffix=='.gz':
  with gzip.open(path,'rt') as stream:return json.load(stream)
 if path.exists():return json.loads(path.read_text())
 with gzip.open(str(path)+'.gz','rt') as stream:return json.load(stream)

def archive(root):
 hashes=[]
 for p in sorted(root.rglob('*.json')):
  if p.name in {'summary.json','compression.json'} or p.stat().st_size<100000:continue
  raw=p.read_bytes();target=Path(str(p)+'.gz');target.write_bytes(gzip.compress(raw,mtime=0));p.unlink();hashes.append({'file':str(target.relative_to(root)),'uncompressed_sha256':hashlib.sha256(raw).hexdigest(),'compressed_sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'uncompressed_bytes':len(raw)})
 if hashes:(root/'large-json-compression.json').write_text(json.dumps(hashes,indent=2)+'\n')
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('root',type=Path);archive(p.parse_args().root)
