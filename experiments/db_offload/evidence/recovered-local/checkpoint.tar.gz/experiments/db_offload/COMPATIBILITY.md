# Compatibility and trust boundaries

The actual capability spike, nine default real-Relate pytest cases and nineteen
cross-engine native-projection checks are separate from production-memory tests.
`evidence/native-gates.json` lists every executed check and unsupported category.

| Contract | Executed evidence | Boundary / gap |
|---|---|---|
| Qualified IDs, exact versions/digests | Actual native payload validation, duplicate imports and corruption | IDs are application-qualified; no database ACL claim |
| Scope before top-k / hidden influence | Native starvation spike; allowed-only index partitions; foreign partition does not change permitted results | No trusted shared-publication profile; materialization remains app-owned |
| No invisible bridges | Scope predicate on all path nodes/edges; permitted endpoint projection; bound typed adjacency validation | Source-level access policy is resolved before index construction |
| Read-after-write and withdrawal | Build separate native generations; old generation remains readable | Not yet connected to the complete canonical mutation API |
| Revisions and restored wording | Generation hash includes complete records/vectors; exact payload verifier | Old observation replay/retraction semantics stay in `ReliableStore`, not Neo4j queries |
| Retraction / expiry / historical cutoff | All arms receive identical explicit permitted sets; new generation excludes withdrawn source; historical tasks exclude future versions | Retraction and expiry controls are local projection exclusions; no claim of general native temporal policy |
| Imported trust / approval | Self-verified or self-approved imports rejected by app validator before DB insertion | Integrity, source verification, human approval remain distinct |
| Complete conflict bundles / budgets | Required supplied closure fits in full or produces explicit error; whole cards omitted deterministically | Automatic conflict discovery/required bundle construction is not wired into this candidate experiment |
| Deterministic ordering | Entire native partition requested, score then qualified-ID ordering; three repeated selections | Approximate top-k boundary ties need separate policy before adoption |
| Restart and index freshness | Relate close/reopen tests; actual Neo4j server stop/start with identical result; manifest and dropped-index failures explicit | Full model-facing cold CLI recovery and uncertain publication repair not established for native profiles |
| Storage failure and replay | Retained canonical-memory regression tests + actual Relate transaction rollback | Device-failure injection/native Neo4j evidence-ledger integration unsupported; not marked passing |

The read-only offline agent command is untouched. Neo4j runs in a dedicated parent
harness with literal loopback HTTP/Bolt only, while inference executes inside the
existing kernel-network-denied subprocess. Owner approval is not an agent tool.
No kernel/broker/M4 authentication is ported. A source digest proves content
identity, not truth or successful verification of the claim.
