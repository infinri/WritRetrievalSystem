"""Equal-access learned reranking ablation; never part of ownership timings."""
import argparse,gzip,json,os,subprocess,sys,time
from pathlib import Path
from .data import load,permitted,render,score

def main():
 p=argparse.ArgumentParser();p.add_argument('--input',type=Path,required=True);p.add_argument('--model-dir',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();c,t,s=load();tasks={x['id']:x for x in t};selection=json.loads((Path(__file__).parent/'protocol/selection.json').read_text());assert selection['frozen']
 process=subprocess.Popen([sys.executable,'scripts/offline_run.py','-m','experiments.db_offload.rerank_worker','--model-dir',str(a.model_dir)],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,env={**os.environ,'OMP_NUM_THREADS':'2','OPENBLAS_NUM_THREADS':'2'})
 ready=process.stdout.readline()
 if not ready:raise RuntimeError(process.stderr.read()[:2000])
 info=json.loads(ready);path=a.input/'queries.jsonl';raw=gzip.open(str(path)+'.gz','rt') if not path.exists() else path.open();rows=[]
 try:
  for line in raw:
   row=json.loads(line)
   if row['arm'] not in selection['reranker']['apply_equally_to'] or 'error' in row:continue
   task=tasks[row['task_id']];units=permitted(c,task);lookup={x['id']:x for x in units};candidates=row['ranked'][:20];start=time.perf_counter();process.stdin.write(json.dumps({'pairs':[[task['query'],lookup[r['uid']]['text']] for r in candidates]})+'\n');process.stdin.flush();answer=process.stdout.readline()
   if not answer:raise RuntimeError(process.stderr.read()[:2000])
   answer=json.loads(answer);ranked=[{**r,'rerank_logit':v} for r,v in zip(candidates,answer['scores'])];ranked.sort(key=lambda r:(-r['rerank_logit'],r['uid']));out=render(task,ranked,units,json.loads(row['payload'])['generation'],s);added=(time.perf_counter()-start)*1000
   rows.append({'task_id':task['id'],'arm':row['arm'],'family':row['family'],'expected_unknown':task['expected_unknown'],'metrics':score(task,out),'before':row['metrics'],'rerank_additional_ms':added,'cross_encoder_inference_ms':answer['inference_ms'],'reranker_peak_rss_kib':answer['peak_rss_kib'],'composed_e2e_ms':[x+added for x in row['e2e_ms']],'timing_note':'Composed from original E2E plus independent measured rerank/render; not a directly measured full-system latency. Baseline rendering counted twice. No threshold tuning. Empty input remains empty.','ranked':ranked,**out})
 finally:
  raw.close();process.stdin.close();process.wait(timeout=20)
 a.output.mkdir(parents=True,exist_ok=False);(a.output/'model.json').write_text(json.dumps(info,indent=2)+'\n');(a.output/'queries.jsonl').write_text(''.join(json.dumps(r)+'\n' for r in rows));print('reranked',len(rows))
if __name__=='__main__':main()
