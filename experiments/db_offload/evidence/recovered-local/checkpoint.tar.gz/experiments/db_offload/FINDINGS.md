# Database offloading findings

**Retain the working local baseline. No architecture replacement is adopted.**
The tested native variants do not establish an end-to-end quality, speed and
resource improvement over the strongest matched flat control. This conclusion
is version-, corpus- and configuration-specific, not a claim that graph databases
or Rust cannot improve retrieval. See [decision and removal audit](DECISION.md).

## Evidence and denominators

The frozen protocol preceded prototype changes; PR #4 contains the fixture freeze.
PR #5 contains native Relate B/C. PR #6 contains Neo4j D, thin Rust clients and
committed development-only selection before held-out execution. All files remain
inside this namespace. Original Phase 1–3 fixtures/evidence are hash-checked and
unchanged, including Phase 3's primary 3/10 connected versus 4/10 flat result.
Its discarded exploratory 7/10 is not used.

There are 64 task formulations, 32 topic families, split into 32 development /
32 held-out tasks (16 families each). Held-out positives: 20 tasks / ten families,
24 target-proxy instances, only five unique source versions. Unknown controls:
12 tasks / six families. Four public V2 source files plus historical Phase 3
sections supply 305 overlapping passages and 288 bound adjacency/reference edges;
a normal current view has 188 permitted passages. Historical views exclude later
source versions. Scope, withdrawn/expired associations and output ceilings are
identical across matched arms. Synthetic growth supplies no quality evidence.

Labels are model-authored, **NOT HUMAN REVIEWED**. The 120-character source proxies
and exact version/digest requirements establish literal target delivery, not
independently adjudicated complete answers. A source URI alone never counts;
missing/truncated target text does not count. Wider qualifications still require
review. Precision uses incomplete judgments and nDCG is reported only for the
16 single-target positive tasks. Deduplicated source coverage alone hides the
per-query regressions; both are published. There is no live generative-agent
outcome or causal success evidence.

## Held-out retrieval

Full per-task payloads, ranked candidates, omissions, scopes, gold references and
three repeated timings are in `evidence/heldout-{matched,best}/queries.jsonl.gz`.
[Tables](TABLES.md), [machine summary](evidence/summary.json), and the standalone
[quality/latency and exact-oracle curves](comparison.svg) include all arms.

Matched policy: A-hybrid delivers all labeled targets for **14/20** tasks (17/24
proxy instances); B-flat/C-flat **13/20** (15/24); D-flat **12/20** (14/24).
Connected A/B/C/D each reach **8/20** (9/24), showing crowding under a common full
payload budget. The best-configured track improves A/B/D connected to 9/20;
C-connected stays 8/20. Flat choices remain the same. A-lexical reaches 13/20
with MRR .410, higher than A-hybrid .300: coverage and ordering trade off.

Native replacements do not meet the pre-registered paired-family noninferiority
rule against A-hybrid. Matched lower 95% bounds for complete-target delivery are
-.15 for B/C-flat and -.20 for D-flat (margin -.03). Connected is -.50. All
hybrid arms produce an empty context on only **4/12** warranted-unknown controls;
none unnecessarily abstain on the 20 positives. This is an empty-context metric,
not proof that an actual model would or would not make an unsupported claim.
Returned version/digest/scoping checks pass; this does not prove source truth.

The development advantage for Neo4j (18/20 versus flat A/B/C 17/20) did not survive
held-out evaluation. No configuration changed after opening held-out results.
Matched and best timings vary substantially with shared-host contention; do not
cherry-pick either run as a production speed claim.

## Native capability and correctness

Actual Relate 1.0.1 and Neo4j Community 5.26.0 support the tested vector/fulltext,
Cypher RRF and bounded traversal queries. Native top-k followed by project
filtering loses permitted candidates in the starvation fixture. Allowed-only
immutable index partitions avoid hidden-vector and hidden-IDF influence, while
adding import, memory and update costs. This is application materialization,
not database authorization. Fulltext metadata defaults do not make analyzer
scores equivalent. Source inspection and exact-oracle measurements distinguish
Relate's pinned flat population scan from Neo4j's ANN implementation; misleading
compatibility HNSW configuration names are not taken as execution evidence.

Ten real-Relate pytest cases cover candidates, restart, scope, corruption,
required conflict budgets, typed cycles, rollback and failed replacement
publication with previous-generation recovery. Nineteen separately executed
cross-engine projection gates pass, including actual Neo4j process restart.
[Compatibility](COMPATIBILITY.md) lists what these checks establish and what they
do not. Missing live canonical-memory projection, trusted shared publication,
automatic conflict bundle construction, canonical Neo4j feedback/replay and
storage-device recovery are unsupported adoption gates. No passing count masks
those gaps or grants execution authority.

## Learned reranking, separately

A fixed Apache-2.0 local `cross-encoder/ms-marco-MiniLM-L6-v2` export reranks at most
20 candidates equally for A-hybrid/B-flat/C-flat/D-flat. Revision, weights,
tokenizer, truncation and thread settings are pinned. It is a learned cross-encoder;
MiniLM embeddings and RRF are not learned rerankers. The optional ablation was
frozen before held-out access and was justified by development misses, with no
threshold/config search on held-out data.

A's target-delivery count remains **14/20**, with MRR .300 -> .581. B/C rise from
13/20 to **14/20**, MRR .292 -> .581; D rises 12/20 -> **13/20**, MRR .285 -> .531.
Abstention remains 4/12. Additional processing median is about **1.91 s**, p95
**4.16 s** over 128 calls on this host; reranker worker peak RSS is **425,488 KiB**.
Per-task unchanged results/regressions are retained alongside gains. Composed
E2E timings add this independently measured cost to earlier runs and count an
extra render; they are not directly measured full-system latency or combined
peak memory. The cost does not establish an adoption win or successful outcomes.

## Performance, Rust and preserved workflows

[All 24 growth/concurrency profiles](PERFORMANCE.md) and raw resource/timing files
report 1x/10x/100x and one/four readers, including timeouts, readiness failures and
resource limits. Complete profiles have 1,000 samples; failed profiles do not
receive adoption percentiles. Real-data quality and synthetic load are separate.
Startup, index construction, warm queries, recovery, CPU accounting limitations,
RSS, disk and cache conditions are explicit. No remote-server or full cold CLI
context recovery is inferred from loopback/static-generation measurements.

Initial Python-then-Rust probes are retained, including apparently favorable
numbers. The later randomized paired flat probes (200 pairs each, ten warmup
pairs, four development inputs) show no Rust p95 win: Relate Python 99.90 ms /
Rust 109.68 ms; Neo4j Python 44.42 ms / Rust 46.73 ms. Different Relate bindings,
HTTP clients and shared-host variation preclude language-only conclusions. The
thin wrappers execute equivalent queries/data while the outer application
contracts remain Python; a complete Rust context pipeline is not claimed.

Original weighted retrieval was rerun on all 253 prompts in four arms: **1,012
outputs exactly unchanged** against Phase 2 after excluding timing. Thread limits
and timing repetition counts are disclosed. All original 117 tests plus ten
native tests pass; the five original demo checks and nine process-restart /
retraction scripted demo checks pass. These deterministic checks establish
retained workflows, not actual agent success. `pip check` passes.

The actual tool-calling generative-model harness is prepared with paired repeats,
random order, identical prompts/tools/budgets, frozen packets and blind-review
output. **NOT RUN:** no authorized local generative endpoint and exact model
identity/revision are configured. The embedding encoder cannot substitute for
that model. Owner approval stays outside model tools. Pending label and blind
review materials are in `review/`.

## Practical split

Keep Relate persistence and the supported application reliability/memory contract.
Retain flat lexical/vector/hybrid controls; do not adopt unconditional graph
expansion. Keep B/C/D/E as experiments. No modules/dependencies are removed, no
whole Rust rewrite or server-profile winner is justified, and no superiority
claim is published. Further native optimization needs a new frozen held-out set
and the missing integration gates; current provisional labels first need actual
independent review. Full reproducible commands and limitations are in README.md,
MEASUREMENT-NOTES.md and DECISION.md.
