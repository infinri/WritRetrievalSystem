# Held-out comparison tables

All labels are provisional. Twenty positive tasks (ten families), twelve unknown controls (six families), 24 clause targets per arm. Empty-context abstention is a retrieval metric, not a live-agent judgment. p95 uses 96 repeated timings, not 96 independent tasks; no p99 is reported here.

## matched

| Arm | Complete labelled targets /20 | Clauses /24 | MRR | Empty abstentions /12 | E2E p95 ms | Citation/scope errors |
|---|---:|---:|---:|---:|---:|---:|
| A-connected | 8 | 9 | 0.221 | 4 | 245.9 | 0 |
| A-hybrid | 14 | 17 | 0.300 | 4 | 93.7 | 0 |
| A-lexical | 13 | 15 | 0.410 | 4 | 174.5 | 0 |
| A-vector | 8 | 9 | 0.232 | 4 | 136.5 | 0 |
| B-connected | 8 | 9 | 0.221 | 4 | 143.9 | 0 |
| B-flat | 13 | 15 | 0.292 | 4 | 251.2 | 0 |
| C-connected | 8 | 9 | 0.221 | 4 | 266.8 | 0 |
| C-flat | 13 | 15 | 0.292 | 4 | 311.4 | 0 |
| D-connected | 8 | 9 | 0.221 | 4 | 259.9 | 0 |
| D-flat | 12 | 14 | 0.285 | 4 | 389.0 | 0 |

Family-bootstrap comparisons against A-hybrid (one-sided 95% lower bounds):

| Arm | Complete lower | MRR lower | Provisional noninferiority |
|---|---:|---:|---|
| A-connected | -0.500 | -0.138 | False |
| A-hybrid | 0.000 | 0.000 | True |
| A-lexical | -0.150 | -0.029 | False |
| A-vector | -0.550 | -0.140 | False |
| B-connected | -0.500 | -0.138 | False |
| B-flat | -0.150 | -0.018 | False |
| C-connected | -0.500 | -0.138 | False |
| C-flat | -0.150 | -0.018 | False |
| D-connected | -0.500 | -0.138 | False |
| D-flat | -0.200 | -0.034 | False |

## best

| Arm | Complete labelled targets /20 | Clauses /24 | MRR | Empty abstentions /12 | E2E p95 ms | Citation/scope errors |
|---|---:|---:|---:|---:|---:|---:|
| A-connected | 9 | 11 | 0.260 | 4 | 88.6 | 0 |
| A-hybrid | 14 | 17 | 0.300 | 4 | 70.4 | 0 |
| A-lexical | 13 | 15 | 0.410 | 4 | 75.9 | 0 |
| A-vector | 8 | 9 | 0.232 | 4 | 110.2 | 0 |
| B-connected | 9 | 11 | 0.262 | 4 | 90.1 | 0 |
| B-flat | 13 | 15 | 0.292 | 4 | 97.1 | 0 |
| C-connected | 8 | 9 | 0.221 | 4 | 134.3 | 0 |
| C-flat | 13 | 15 | 0.292 | 4 | 134.8 | 0 |
| D-connected | 9 | 11 | 0.262 | 4 | 164.9 | 0 |
| D-flat | 12 | 14 | 0.285 | 4 | 181.8 | 0 |

Family-bootstrap comparisons against A-hybrid (one-sided 95% lower bounds):

| Arm | Complete lower | MRR lower | Provisional noninferiority |
|---|---:|---:|---|
| A-connected | -0.400 | -0.121 | False |
| A-hybrid | 0.000 | 0.000 | True |
| A-lexical | -0.150 | -0.029 | False |
| A-vector | -0.550 | -0.140 | False |
| B-connected | -0.400 | -0.120 | False |
| B-flat | -0.150 | -0.018 | False |
| C-connected | -0.500 | -0.138 | False |
| C-flat | -0.150 | -0.018 | False |
| D-connected | -0.400 | -0.120 | False |
| D-flat | -0.200 | -0.034 | False |

