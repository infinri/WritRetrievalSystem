"""Standalone exact-data comparison plots; matplotlib is an optional reporting tool."""
import json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=Path(__file__).parent

def main():
 s=json.loads((ROOT/'evidence/summary.json').read_text());fig,axes=plt.subplots(1,2,figsize=(11,4.5),layout='constrained')
 for track,marker in [('matched','o'),('best','x')]:
  for arm,r in s['partitions'][track]['summary'].items():
   if arm in {'A-hybrid','A-lexical','B-flat','C-flat','D-flat','C-connected'}:
    axes[0].scatter(r['e2e_p95_ms'],r['complete_answers']/20,marker=marker);axes[0].annotate(arm+' '+track,(r['e2e_p95_ms'],r['complete_answers']/20),fontsize=7,xytext=(3,3),textcoords='offset points')
 axes[0].set(xlabel='Measured E2E p95 (ms); shared host',ylabel='Complete labelled target delivery /20',ylim=(0,1),title='Held-out proxy quality / latency; unreviewed')
 for backend in ['Relate-exact','Neo4j-ANN','HNSW-ef20','HNSW-ef50','HNSW-ef100']:
  r=[s['vector_curves'][backend+':'+str(k)] for k in (5,10,20,50)];axes[1].plot([x['raw_query_p95_ms'] for x in r],[x['mean_strict_recall'] for x in r],marker='.',label=backend)
 axes[1].set(xlabel='Raw vector query p95 (ms), precomputed vectors',ylabel='Exact-oracle recall',ylim=(.75,1.02),title='k=5/10/20/50; 188 units; separate from relevance');axes[1].legend(fontsize=7)
 for ax in axes:ax.grid(alpha=.2)
 fig.savefig(ROOT/'comparison.svg');plt.close(fig)
if __name__=='__main__':main()
