"""Pinned local learned cross-encoder, executed only inside offline_run.py."""
import argparse,hashlib,json,sys,time,resource
from pathlib import Path
import numpy as np
import onnxruntime as ort
from tokenizers import Tokenizer

def main():
 p=argparse.ArgumentParser();p.add_argument('--model-dir',type=Path,required=True);a=p.parse_args();manifest=json.loads((a.model_dir/'manifest.json').read_text());expected=json.loads((Path(__file__).parent/'protocol/reranker-artifacts.json').read_text())
 if manifest!=expected:raise ValueError('reranker manifest differs from committed artifact pin')
 for name,sha in manifest['sha256'].items():
  if hashlib.sha256((a.model_dir/name).read_bytes()).hexdigest()!=sha:raise ValueError('reranker artifact mismatch '+name)
 options=ort.SessionOptions();options.intra_op_num_threads=2;options.inter_op_num_threads=1;start=time.perf_counter();session=ort.InferenceSession(str(a.model_dir/'model.onnx'),sess_options=options,providers=['CPUExecutionProvider']);tokenizer=Tokenizer.from_file(str(a.model_dir/'tokenizer.json'));tokenizer.enable_truncation(max_length=384);tokenizer.enable_padding(pad_id=0,pad_token='[PAD]');print(json.dumps({'ready':True,'manifest':manifest,'startup_ms':(time.perf_counter()-start)*1000}),flush=True)
 for line in sys.stdin:
  request=json.loads(line);start=time.perf_counter();scores=[]
  for i in range(0,len(request['pairs']),8):
   encoding=tokenizer.encode_batch([tuple(x) for x in request['pairs'][i:i+8]]);inputs={'input_ids':np.array([x.ids for x in encoding],dtype=np.int64),'attention_mask':np.array([x.attention_mask for x in encoding],dtype=np.int64),'token_type_ids':np.array([x.type_ids for x in encoding],dtype=np.int64)};scores.extend(session.run(None,{x.name:inputs[x.name] for x in session.get_inputs()})[0].reshape(-1).tolist())
  print(json.dumps({'scores':scores,'inference_ms':(time.perf_counter()-start)*1000,'peak_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}),flush=True)
if __name__=='__main__':main()
