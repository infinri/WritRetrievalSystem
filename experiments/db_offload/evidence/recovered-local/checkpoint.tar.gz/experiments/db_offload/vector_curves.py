"""ANN recall versus exact oracle, separate from relevance; fixed development inputs."""
import argparse,contextlib,hashlib,json,time
from pathlib import Path
import hnswlib,numpy as np
from .data import load,permitted,norm,keywords
from .adapters import Native,Flat
from .model import Model
from .engine import neo4j_server

def main():
 p=argparse.ArgumentParser();p.add_argument('--model-dir',type=Path,required=True);p.add_argument('--neo4j-home',type=Path,required=True);p.add_argument('--work',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();a.work.mkdir(parents=True,exist_ok=False)
 c,t,s=load();tasks=[x for x in t if x['partition']=='development'];u=permitted(c,tasks[0]);rows=[];analyzers=[]
 with contextlib.ExitStack() as stack:
  m=Model(a.model_dir);stack.callback(m.close);v,_=m.encode([x['text'] for x in u]);q,_=m.encode([x['query'] for x in tasks]);v=norm(v);q=norm(q)
  h=hnswlib.Index(space='cosine',dim=384);h.init_index(max_elements=len(u),ef_construction=100,M=16,random_seed=s['seed']);h.add_items(v,np.arange(len(u)),num_threads=1);h.set_num_threads(1)
  db,_,_=stack.enter_context(neo4j_server(a.neo4j_home,a.work/'neo4j',readiness_seconds=60))
  r=Native(a.work/'relate');d=Native(db=db,kind='neo4j');stack.callback(r.close);rs=r.prepare(u,v,[]);ds=d.prepare(u,v,[])
  flat=Flat();fs=flat.prepare(u,v,[])
  for query in ('approval','approved','owner-confirmed','revision AND digest','the source','D-035','source*'):
   z={}
   for name,adapter,scope in [('Tantivy',flat,fs),('Relate',r,rs),('Neo4j',d,ds)]:z[name]=adapter.lists(scope,query,q[0],20,2)[0]
   analyzers.append({'query':query,'prepared':keywords(query),'ranks':z})
  for ti,task in enumerate(tasks):
   exact=v@q[ti];order=sorted(range(len(u)),key=lambda i:(-float(exact[i]),u[i]['id']))
   for k in (5,10,20,50):
    oracle=order[:k];threshold=float(exact[oracle[-1]])
    for backend in ('Relate-exact','Neo4j-ANN','HNSW-ef20','HNSW-ef50','HNSW-ef100'):
     timings=[];ids=[]
     for _ in range(3):
      start=time.perf_counter()
      if backend.startswith('HNSW'):
       h.set_ef(max(k,int(backend.split('ef')[1])));idx,_=h.knn_query(q[ti],k=k,num_threads=1);ids=[int(x) for x in idx[0]]
      else:
       n,scope=(r,rs) if backend=='Relate-exact' else (d,ds);records=n.execute(f"CALL db.index.vector.queryNodes('{n.views[scope]['vi']}',$k,$v) YIELD node,score RETURN node.uid AS uid,score",{'k':k,'v':q[ti].tolist()});byid={x['id']:i for i,x in enumerate(u)};ids=[byid[x['uid']] for x in records]
      timings.append((time.perf_counter()-start)*1000)
     rows.append({'task_id':task['id'],'backend':backend,'k':k,'n':len(u),'strict_recall':len(set(ids)&set(oracle))/k,'tie_aware_recall':sum(float(exact[i])>=threshold-1e-6 for i in ids)/k,'latency_ms':timings,'oracle_ids':[u[i]['id'] for i in oracle],'returned_ids':[u[i]['id'] for i in ids],'note':'raw search with precomputed vectors, no policy/validation/rendering; not semantic relevance'})
 result={'version':'vector-oracle/1','partition':'development','unit_count':len(u),'vector_sha256':hashlib.sha256(v.tobytes()).hexdigest(),'metric':'normalized float32 cosine; native score rebound','hnsw':{'M':16,'ef_construction':100,'single_thread':True,'seed':s['seed']},'neo4j':'fixed native index; query ef not exposed in this API','rows':rows,'analyzer_probe':analyzers,'analyzers':'Tantivy Index default; Relate 1.0.1 native fulltext; Neo4j 5.26 standard-no-stop-words default. Identical neutralized query text does not guarantee identical tokenization/scoring.'}
 a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(result,indent=2)+'\n');print('rows',len(rows))
if __name__=='__main__':main()
