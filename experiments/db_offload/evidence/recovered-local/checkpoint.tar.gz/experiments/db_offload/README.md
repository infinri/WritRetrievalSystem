# Database offloading bake-off

Experimental, read-only comparison entry points for retrieval, JIT context and
persistent graph search. **No production replacement is adopted.** Read the
[findings](FINDINGS.md), [decision/removal audit](DECISION.md), [all quality tables](TABLES.md),
[resource results](PERFORMANCE.md), [compatibility gates](COMPATIBILITY.md),
[measurement limits](MEASUREMENT-NOTES.md), and [attribution](ATTRIBUTION.md).
All original Phase 1–3 evidence and the offline agent remain intact.

## Install pinned inputs

From the repository root on Linux x86_64, with Python 3.12, GCC/G++, and Java 21
for the optional Neo4j comparison:

```sh
python -m venv .venv
. .venv/bin/activate
CC=gcc CXX=g++ HNSWLIB_NO_NATIVE=1 pip install --no-cache-dir -e '.[dev]' -r experiments/db_offload/requirements.txt
python scripts/prepare_model.py --output data/model
python -m experiments.db_offload.bootstrap --output data/bakeoff-tools
```

Exact executed Python/library versions, host, archive hashes and disk accounting
are in `evidence/environment.json`; root `requirements-validated.txt` pins the
original core stack. Relate 1.0.1 is mandatory; Neo4j Community 5.26.0 / driver
5.28.2 and psutil 7.1.3 are experiment-only. Java is not installed/modified by this
harness. Tools/model preparation requires network; inference remains offline.
No paid service, credentials, privileged setup or Docker is required.

The source/dataset/config freeze is `protocol/{PROTOCOL.md,settings.json,frozen.json}`.
Source revisions and byte hashes are authoritative. `protocol/selection.json` was
committed before held-out execution. Do not tune against published held-out
results or overwrite frozen inputs; further tuning needs a new held-out set.
New output/work directories must not already exist.

## Capability, correctness and historical behavior

```sh
python -m experiments.db_offload.capability --output data/repro-capability.json --neo4j-home data/bakeoff-tools/neo4j-community-5.26.0
python scripts/offline_run.py -m pytest -q
python scripts/offline_run.py -m unittest discover -s tests -v
python -m experiments.db_offload.native_gates --neo4j-home data/bakeoff-tools/neo4j-community-5.26.0 --work data/repro-native-gates --output data/repro-native-gates.json
python -m experiments.db_offload.index_metadata --neo4j-home data/bakeoff-tools/neo4j-community-5.26.0 --work data/repro-index-info --output data/repro-index-info.json
python scripts/offline_run.py -m experiments.db_offload.historical --model-dir data/model --work data/repro-original --output data/repro-original-results
```

The Neo4j harness owns its child process and accepts only dedicated literal
loopback HTTP/Bolt endpoints. Start/stop/readiness is included where documented.
It does not weaken `scripts/offline_run.py` or the supported read-only agent.
The source corpus is already frozen locally; original Writ is never edited.
To rerun the unchanged nine-check production restart/retraction demo, use
`docs/PHASE3.md` commands with new output paths. `evidence/production-demo` records
its execution in this milestone; do not mistake it for native-ledger integration.

## Development and frozen held-out tracks

```sh
python -m experiments.db_offload.run --partition development --arms A-lexical,A-vector,A-hybrid,A-connected,B-flat,B-connected,C-flat,C-connected,D-flat,D-connected --model-dir data/model --neo4j-home data/bakeoff-tools/neo4j-community-5.26.0 --work data/repro-dev --output data/repro-dev-results
python -m experiments.db_offload.run --partition heldout --selection experiments/db_offload/protocol/selection.json --track matched --arms A-lexical,A-vector,A-hybrid,A-connected,B-flat,B-connected,C-flat,C-connected,D-flat,D-connected --model-dir data/model --neo4j-home data/bakeoff-tools/neo4j-community-5.26.0 --work data/repro-matched --output data/repro-matched-results
python -m experiments.db_offload.run --partition heldout --selection experiments/db_offload/protocol/selection.json --track best --arms A-lexical,A-vector,A-hybrid,A-connected,B-flat,B-connected,C-flat,C-connected,D-flat,D-connected --model-dir data/model --neo4j-home data/bakeoff-tools/neo4j-community-5.26.0 --work data/repro-best --output data/repro-best-results
```

A is warm flat Tantivy/exact cosine/RRF plus graph control. Original weighted
retrieval remains the separate historical control. B uses Relate candidate
search with application fusion. C/D move fusion and typed expansion into Cypher.
All retain application binding/visibility validation and whole-payload rendering.
Drop D arms for an entirely local Relate experiment without Java. Snapshot
publication here covers immutable candidate partitions, not a complete canonical
memory/evidence integration. Unsupported adoption gates are listed explicitly.

## Oracle, growth and independent learned reranking

```sh
python -m experiments.db_offload.vector_curves --model-dir data/model --neo4j-home data/bakeoff-tools/neo4j-community-5.26.0 --work data/repro-curves --output data/repro-curves.json
python -m experiments.db_offload.suite --model-dir data/model --neo4j-home data/bakeoff-tools/neo4j-community-5.26.0 --work data/repro-performance --output data/repro-performance-results
python -m experiments.db_offload.prepare_reranker --output data/reranker
python -m experiments.db_offload.rerank --input data/repro-matched-results --model-dir data/reranker --output data/repro-reranker-results
```

The suite runs 24 randomized 1x/10x/100x × one/four reader profiles, targeting
1,000 samples with the registered limits. Allow roughly an hour on this shared
host; failures are data. Exact-vector oracle recall is separate from relevance.
Reranking is optional, CPU/local, fixed model/tokenizer/config and candidate cap.
It does not change the core ownership selection. Its composed timing is labeled.

## Thin Rust query clients

Install Rust 1.85.1 in user space (e.g. `rustup toolchain install 1.85.1 --profile minimal`),
then build against the externally pinned Relate C ABI 2:

```sh
RELATE_FFI_DIR="$(pwd)/data/bakeoff-tools" cargo +1.85.1 build --release --locked --manifest-path experiments/db_offload/rust/Cargo.toml
python -m experiments.db_offload.language_pairs --backend relate --rust experiments/db_offload/rust/target/release/writ-db-thin-client --ffi data/bakeoff-tools --model-dir data/model --work data/repro-paired-relate --output data/repro-paired-relate.json
python -m experiments.db_offload.language_pairs --backend neo4j --rust experiments/db_offload/rust/target/release/writ-db-thin-client --ffi data/bakeoff-tools --model-dir data/model --neo4j-home data/bakeoff-tools/neo4j-community-5.26.0 --work data/repro-paired-neo4j --output data/repro-paired-neo4j.json
```

The query client changes; backend data, queries/policies and Python outer
validation remain equivalent. This is not a full Rust context pipeline or a
language-only benchmark. Original sequential probes are retained as bring-up.

## Actual model trials and review

`evidence/agent-trials-prepared/status.json` is **NOT RUN**, with zero actual
trials. There is no configured authorized generative host or exact model identity;
the embedding model and this chat session are not substitutes. The frozen-packet
harness can execute real tool-calling trials when those inputs exist:

```sh
WRIT_BAKEOFF_AGENT_ENDPOINT=http://127.0.0.1:8000/v1 WRIT_BAKEOFF_AGENT_MODEL=EXACT_MODEL_ID python -m experiments.db_offload.agent_trials --retrieval-packets experiments/db_offload/review/agent-packets.json --output data/repro-live-trials
```

Only explicitly configured local hosts are accepted. This compares no history,
A-hybrid and C-flat fixed packets with identical prompts/tools/budgets, three
paired repetitions and randomized order. Query rewrites are logged; packet mode
does not pretend to execute a fresh adaptive backend search. Actual outputs,
usage/cost where supplied, traces and blind-review materials are recorded. Labels
and reviews remain pending until a real reviewer completes them; owner approval
is outside agent tools.

`review/labels.csv` contains exact source versions, offsets and review fields.
`blind-contexts.jsonl.gz` omits arm identities; its key is separate. Wider clause
qualifications must be reviewed, not just the 120-character target proxies.
No review, successful outcome or causal rule effect is inferred automatically.

## Evidence format and regeneration

Large traces are losslessly gzip-compressed with recorded raw/compressed hashes.
Use `gzip -cd FILE.jsonl.gz` or Python `gzip.open`. `large_json.read` transparently
opens a `.json` sibling `.gz`; agents can pass the original `.json` packet path.
Raw results retain all per-query errors and omissions. Reports read committed
results without rerunning retrieval or tuning:

```sh
python -m experiments.db_offload.report
python -m experiments.db_offload.performance_report
# Optional reporting-only dependency, used for the committed standalone SVG:
pip install matplotlib==3.10.8
python -m experiments.db_offload.plots
```

Those report commands regenerate files in this experimental namespace. No original
evidence, production CLI, website or canonical store is changed.
