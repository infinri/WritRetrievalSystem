"""Rerun unchanged weighted V1 paths; bounded thread execution, separate evidence."""
import argparse,asyncio
from pathlib import Path
import onnxruntime as ort
from writ_retrieval.evaluation.full_corpus import evaluate

def main():
 p=argparse.ArgumentParser();p.add_argument('--model-dir',type=Path,required=True);p.add_argument('--work',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();a.work.mkdir(parents=True,exist_ok=False)
 original=ort.InferenceSession
 def bounded(*args,**kwargs):
  options=ort.SessionOptions();options.intra_op_num_threads=2;options.inter_op_num_threads=1;return original(*args,sess_options=options,**kwargs)
 ort.InferenceSession=bounded
 args=argparse.Namespace(store=a.work/'graph',fixtures=Path('tests/fixtures'),model_dir=a.model_dir,cache=a.work/'indexes',output=a.output,label='database-bakeoff-historical-regression',budget=2000,repeats=1)
 asyncio.run(evaluate(args))
if __name__=='__main__':main()
