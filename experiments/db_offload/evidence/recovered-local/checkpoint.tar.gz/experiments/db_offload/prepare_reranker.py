"""Optional separate local cross-encoder ablation, pinned before held-out access."""
import argparse,hashlib,json,urllib.request
from pathlib import Path
MODEL='cross-encoder/ms-marco-MiniLM-L6-v2'
REVISION='233902d25c440f23af6f7d6e94d2946bac0bee0a'
def main():
 p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);a=p.parse_args();a.output.mkdir(parents=True,exist_ok=False);hashes={};expected=json.loads((Path(__file__).parent/'protocol/reranker-artifacts.json').read_text())
 for name in ('onnx/model.onnx','tokenizer.json','config.json','README.md'):
  raw=urllib.request.urlopen(f'https://huggingface.co/{MODEL}/resolve/{REVISION}/{name}',timeout=120).read();target=a.output/Path(name).name;target.write_bytes(raw);hashes[target.name]=hashlib.sha256(raw).hexdigest()
  if hashes[target.name]!=expected['sha256'][target.name]:raise ValueError('unpinned reranker artifact '+target.name)
 manifest={'model':MODEL,'revision':REVISION,'license':'Apache-2.0 (model card metadata)','sha256':hashes,'purpose':'separate local learned cross-encoder; not MiniLM embedding or RRF','configuration':{'max_length':384,'batch':8,'intra_op_threads':2,'inter_op_threads':1,'candidate_cap':20,'tie':'logit desc then qualified ID'}}
 (a.output/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps(manifest,indent=2))
if __name__=='__main__':main()
