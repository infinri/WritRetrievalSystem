"""Actual running index/settings introspection, including explicit unsupported APIs."""
import argparse,contextlib,json
from pathlib import Path
import numpy as np
from .data import load,permitted,norm
from .adapters import Native
from .engine import neo4j_server

def main():
 p=argparse.ArgumentParser();p.add_argument('--neo4j-home',type=Path,required=True);p.add_argument('--work',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();a.work.mkdir(parents=True,exist_ok=False);c,t,s=load();u=permitted(c,t[0])[:4];v=norm(np.ones((len(u),384)));result={}
 with contextlib.ExitStack() as stack:
  db,_,_=stack.enter_context(neo4j_server(a.neo4j_home,a.work/'neo4j',readiness_seconds=60));r=Native(a.work/'relate');stack.callback(r.close);d=Native(db=db,kind='neo4j')
  for name,n in [('relate',r),('neo4j',d)]:
   n.prepare(u,v,[]);result[name]=[]
   for query in ('CALL dbms.components()','SHOW INDEXES YIELD name,type,options RETURN name,type,options',"SHOW SETTINGS YIELD name,value WHERE name CONTAINS 'fulltext' RETURN name,value",'CALL db.index.fulltext.listAvailableAnalyzers()'):
    try:result[name].append({'query':query,'rows':n.execute(query)})
    except Exception as e:result[name].append({'query':query,'unsupported_or_error':str(e)})
 a.output.write_text(json.dumps(result,indent=2)+'\n');print('captured actual index metadata')
if __name__=='__main__':main()
