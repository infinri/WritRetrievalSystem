"""Human review materials and frozen packet inputs; never mark them reviewed."""
import csv,gzip,hashlib,json,random
from pathlib import Path
from .data import load

def read_rows(root):
 p=root/'queries.jsonl';stream=p.open() if p.exists() else gzip.open(str(p)+'.gz','rt')
 with stream:return [json.loads(x) for x in stream]

def main():
 root=Path(__file__).parent;c,t,s=load();output=root/'review';output.mkdir(exist_ok=False)
 fields=['task_id','partition','category','query','as_of','expected_unknown','source_uri','source_revision','source_digest','start','end','answer_text','review_status','reviewer','finding','alternative_passage','notes']
 with (output/'labels.csv').open('w',newline='') as file:
  writer=csv.DictWriter(file,fieldnames=fields);writer.writeheader()
  for task in t:
   for gold in task['gold'] or [{}]:writer.writerow({**{k:task.get(k) for k in fields if k in task},**{k:v for k,v in gold.items() if k in fields},'task_id':task['id'],'review_status':'NOT HUMAN REVIEWED'})
 rows=read_rows(root/'evidence/heldout-matched');packets={};blind=[];key=[];order=list(range(len(rows)));random.Random(s['seed']).shuffle(order)
 for i,j in enumerate(order):
  r=rows[j];blind.append({'anonymous_id':i,'task_id':r['task_id'],'payload':r.get('payload'),'error':r.get('error'),'review_status':'UNREVIEWED','rubric':['actual required clause delivered, without missing qualifications','exact source revision and digest','historical cutoff and lifecycle','unresolved contradictions surfaced','warranted unknown; no approval or outcome invented']});key.append({'anonymous_id':i,'arm':r['arm'],'task_id':r['task_id']})
 for r in rows:
  if r['arm'] in {'A-hybrid','C-flat'}:packets.setdefault(r['task_id'],{})['flat' if r['arm']=='A-hybrid' else 'native']=r.get('payload','EXPLICIT RETRIEVAL ERROR')
 (output/'blind-contexts.jsonl').write_text(''.join(json.dumps(r)+'\n' for r in blind));(output/'blind-key.json').write_text(json.dumps(key,indent=2)+'\n');(output/'agent-packets.json').write_text(json.dumps(packets,indent=2)+'\n')
 (output/'README.md').write_text('''# Pending independent review\n\nAll labels and rubric applications are model-authored and unreviewed. No human\nreview or adjudicated outcome is claimed. Read the exact public source versions\nand full section around each 120-character label; the short clause may omit\nqualifications. Record alternatives and warranted unknowns in labels.csv, including\nmissing rationale/verification/outcomes. Do not infer owner approval from a commit.\n\nFor blind review, use blind-contexts.jsonl first, keeping blind-key.json separate.\nScore answer sufficiency, citations, historical/lifecycle correctness, contradictions\nand abstention independently. Review is not causal attribution or execution approval.\n\nagent-packets.json freezes the same-budget A-hybrid and C-flat contexts for the\nNOT RUN live-model harness. This is explicitly a fixed-packet experiment, not\nlive autonomous query rewriting. Actual generative execution needs a separately\nauthorized local OpenAI-compatible host, exact model ID/revision and tools support.\n''')
if __name__=='__main__':main()
